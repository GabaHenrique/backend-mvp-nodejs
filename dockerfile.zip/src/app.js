// 1 Importações
require('dotenv').config();
const express = require('express');
const cors = require('cors');


// 2 Criar app
const app = express();


// 3  Middlewares globais
app.use(express.json());

// 4 Transactions Rotas 
const orderRoutes = require('./routes/orderRoutes');
const adminRoutes = require('./routes/adminRoutes');
const productRoutes = require('./routes/productRoutes');

app.use(cors({
  origin: "http://localhost:5500"
}));
app.use('/orders', orderRoutes);
app.use('/products', productRoutes);
app.use('/admin', adminRoutes);


// 5 Order View
const orderViewRoutes = require('./routes/orderViewRoutes');

app.use('/orders', orderViewRoutes);


// 5 Porta
const PORT = 4001;

// 7 Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
